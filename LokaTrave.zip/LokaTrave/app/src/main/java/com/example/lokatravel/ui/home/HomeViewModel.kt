package com.example.lokatravel.ui.home

data class HomeViewModel(val name: String, val imageResourceId: Int)
